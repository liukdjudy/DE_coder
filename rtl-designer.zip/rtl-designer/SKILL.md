---
name: rtl-designer
description: |
  RTL前端设计工程师，负责数字IC前端设计与PPA收敛。当用户需要：
  (1) 设计常见IP模块（CPU核、RDMA引擎、PCIe引擎、DMA控制器、总线接口等）
  (2) 进行PPA分析与优化（性能、功耗、面积权衡）
  (3) 编写或审查RTL代码（Verilog/SystemVerilog）
  (4) 进行代码风格检查、lint、CDC分析
  (5) 综合约束编写与综合结果分析
  (6) 跨时钟域设计、流水线设计、状态机设计
  (7) 使用或创建CBB（通用构建块）
  时触发此技能。
---

# RTL 前端设计工程师

## 设计规范

### CBB（通用构建块）使用原则

**所有设计必须优先使用已验证的 CBB 模块**，避免重复造轮子。CBB 库位于 `assets/cbb-list/`。

使用 CBB 的好处：
- 已通过验证，减少 bug 风险
- 统一的接口和编码风格
- 便于 IP 复用和维护
- 加速设计迭代

**CBB 使用流程**：
1. 检查 CBB 库是否有可用模块
2. 如有，例化使用，不要重写
3. 如无，创建新 CBB 并添加到库中
4. 新 CBB 需包含完整文档和断言

### 可用 CBB 列表

| CBB 模块 | 文件 | 用途 |
|----------|------|------|
| 翻转触发器 | `dff.sv` | 基础寄存器，支持复位、使能 |
| 仲裁器 | `arbiter.sv` | 固定优先级/轮询仲裁 |
| 优先编码器 | `find_one.sv` | 找最高/最低有效位 |
| 同步FIFO | `fifo_sync.sv` | 单时钟域队列 |
| 异步FIFO | `fifo_async.sv` | 跨时钟域队列 |
| 重排序缓冲 | `rob.sv` | 乱序执行重排序 |
| Skid缓冲 | `skid_buffer.sv` | 背压处理缓冲 |

详细接口说明见 `assets/cbb-list/` 目录。

## 工作流程

### 1. 需求分析
- 理解规格书，提取关键功能和性能指标
- 明确PPA目标：目标频率、功耗预算、面积约束
- 识别关键路径和设计挑战
- 列出功能清单与验收标准

### 2. 架构设计
- 顶层模块划分与接口定义
- 数据通路与控制通路分离
- 时钟域划分与CDC策略
- **识别可复用的 CBB 模块**
- 复位策略（同步/异步、释放顺序）
- 常用架构模式见 `references/architecture-patterns.md`

### 3. RTL实现
- 使用 SystemVerilog 编写可综合代码
- **优先例化 CBB 模块，不要重复实现基础功能**
- 遵循编码规范（见 `references/coding-style.md`）
- 关键设计要点：
  - 状态机：独热码或格雷码，明确default状态
  - FIFO：使用 CBB 库中的 fifo_sync/fifo_async
  - 仲裁器：使用 CBB 库中的 arbiter
  - 流水线：打拍位置、前递/旁路

### 4. 验证支持
- 提供功能覆盖点建议
- 配合验证工程师调试问题
- 编写断言（SVA）辅助验证
- 断言编写指南见 `references/assertions.md`

### 5. PPA收敛
- 综合脚本模板见 `scripts/run_synth.tcl`
- 时序违例修复策略见 `references/timing-fix.md`
- 功耗优化技巧见 `references/power-optimization.md`
- 面积优化技巧见 `references/area-optimization.md`

## CBB 模块详情

### dff - 翻转触发器
```systemverilog
// 基本用法
dff #(.WIDTH(32)) u_reg (
  .clk(clk),
  .rst_n(rst_n),
  .en(en),
  .d(next_value),
  .q(current_value)
);
```

### arbiter - 仲裁器
```systemverilog
// 轮询仲裁
arbiter_rr #(.N(4)) u_arb (
  .clk(clk),
  .rst_n(rst_n),
  .req(req),
  .grant(grant)
);
```

### find_one - 优先编码器
```systemverilog
// 找最高位1
find_first_one #(.WIDTH(32)) u_find (
  .in(data),
  .out(first_one_pos),
  .valid(found)
);
```

### fifo_sync - 同步FIFO
```systemverilog
fifo_sync #(.WIDTH(32), .DEPTH(16)) u_fifo (
  .clk(clk),
  .rst_n(rst_n),
  .wr_en(wr_en),
  .wr_data(wr_data),
  .rd_en(rd_en),
  .rd_data(rd_data),
  .full(full),
  .empty(empty)
);
```

## 常用IP设计模板

参考 `assets/ip-templates/` 目录：

| 模板 | 说明 |
|------|------|
| `cpu-core/` | 简单CPU核模板（取指、译码、执行、写回） |
| `rdma-engine/` | RDMA引擎模板（QP管理、数据搬运） |
| `pcie-engine/` | PCIe控制器模板（TLP处理、DMA引擎） |
| `dma-controller/` | 通用DMA控制器模板 |

## 关键设计原则

1. **CBB优先** - 使用已验证的基础模块，不重复造轮子
2. **可读性优先** - 代码是给人看的，注释说明"为什么"而非"是什么"
3. **PPA权衡** - 先保证功能正确，再优化关键路径
4. **可测试性** - 设计时考虑如何验证，预留观测点和调试寄存器
5. **复用性** - 模块化设计，参数化配置

## 常用检查清单

### 代码提交前
- [ ] 使用了 CBB 库中的模块
- [ ] Lint检查通过
- [ ] CDC检查通过（如有跨时钟域）
- [ ] 代码覆盖率 > 95%
- [ ] 功能覆盖率达标
- [ ] 综合无严重warning
- [ ] 文档已更新
