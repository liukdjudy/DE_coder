# 断言编写指南

## SVA断言基础

### 断言类型
| 类型 | 关键字 | 用途 |
|------|--------|------|
| 立即断言 | assert | 过程块内立即检查 |
| 并发断言 | assert property | 时序属性检查 |
| 覆盖 | cover property | 功能覆盖收集 |
| 假设 | assume property | 约束形式验证 |

## 立即断言

### 基本语法
```systemverilog
// 过程块中使用
always_comb begin
  assert (a != b) else $error("a should not equal b");
end

// 带标签
always_ff @(posedge clk) begin
  UNIQUE_REQ: assert (req_onehot || req == '0)
    else $warning("Multiple requests detected");
end
```

## 并发断言

### 基本语法
```systemverilog
// 简单断言
assert property (@(posedge clk) req |-> ##[1:3] ack);

// 带标签
REQ_ACK: assert property (@(posedge clk)
  req |-> ##[1:3] ack
) else $error("ACK not received within 3 cycles");
```

### 时序运算符
| 运算符 | 含义 | 示例 |
|--------|------|------|
| `##n` | 延迟n周期 | `##1 a` |
| `##[m:n]` | 延迟m到n周期 | `##[1:5] a` |
| `##[+]` | 延迟>=1周期 | `##[+] a` |
| `##[*]` | 延迟>=0周期 | `##[*] a` |
| `a ##1 b` | a后1周期b | `req ##1 ack` |
| `a |-> b` | a发生则b立即开始 | `req |-> ack` |
| `a |=> b` | a发生则b下一周期开始 | `req |=> ack` |
| `a throughout b` | a在整个b期间保持 | `valid throughout burst` |
| `a within b` | a在b期间发生 | `ack within req_burst` |
| `a intersect b` | a和b同时开始结束 | `start intersect end` |

## 常用断言模式

### 1. 握手协议断言
```systemverilog
// REQ-ACK协议
property req_ack_protocol;
  @(posedge clk)
  req |-> ##[1:MAX_WAIT] ack;
endproperty

assert property (req_ack_protocol)
  else $error("ACK timeout");

// ACK后REQ必须拉低
property req_deassert_after_ack;
  @(posedge clk)
  ack |-> !req ##1 !req;
endproperty

assert property (req_deassert_after_ack);
```

### 2. FIFO断言
```systemverilog
// 满时不允许写
property no_write_when_full;
  @(posedge clk)
  fifo_full |-> !wr_en;
endproperty

assert property (no_write_when_full);

// 空时不允许读
property no_read_when_empty;
  @(posedge clk)
  fifo_empty |-> !rd_en;
endproperty

assert property (no_read_when_empty);

// 指针不越界
property ptr_within_bound;
  @(posedge clk)
  wr_ptr < FIFO_DEPTH && rd_ptr < FIFO_DEPTH;
endproperty

assert property (ptr_within_bound);
```

### 3. 状态机断言
```systemverilog
// 状态转换合法性
property valid_state_transition;
  @(posedge clk)
  state |-> next_state inside {VALID_NEXT_STATES};
endproperty

// 必须有下一个状态
always_ff @(posedge clk) begin
  assert (next_state != state_t'(X))
    else $error("Next state undefined");
end

// 状态转换覆盖率
cover property (@(posedge clk) state == IDLE ##1 state == ACTIVE);
cover property (@(posedge clk) state == ACTIVE ##1 state == DONE);
```

### 4. 总线协议断言
```systemverilog
// AXI VALID/READY协议
property valid_ready_protocol;
  @(posedge clk)
  valid && !ready |-> $stable(data);
endproperty

assert property (valid_ready_protocol)
  else $error("Data changed while valid asserted and ready low");

// 连续传输
property back_to_back_transfer;
  @(posedge clk)
  valid && ready |-> ##1 valid;
endproperty

cover property (back_to_back_transfer);
```

### 5. 复位断言
```systemverilog
// 复位后状态检查
property reset_state;
  @(posedge clk)
  !rst_n |=> state == IDLE;
endproperty

assert property (reset_state);

// 复位释放后信号稳定
property stable_after_reset;
  @(posedge clk)
  $fell(rst_n) |-> ##[1:5] $stable(control_signals);
endproperty

assert property (stable_after_reset);
```

## 覆盖断言

### 功能覆盖收集
```systemverilog
// 覆盖点
cover property (@(posedge clk) state == IDLE);
cover property (@(posedge clk) fifo_full);
cover property (@(posedge clk) error_flag);

// 边界覆盖
cover property (@(posedge clk) counter == MAX_VALUE);
cover property (@(posedge clk) counter == 0);

// 时序覆盖
cover property (@(posedge clk) req ##[1:10] ack);
cover property (@(posedge clk) start ##[+] done);
```

## 断言最佳实践

### 1. 命名规范
```systemverilog
// 使用有意义的标签
A_FIFO_NO_OVERFLOW: assert property (...);
A_FIFO_NO_UNDERFLOW: assert property (...);
C_FIFO_FULL_EVENT: cover property (...);
```

### 2. 断言位置
- 接口信号断言放在模块边界
- 内部信号断言放在相关逻辑附近
- 断言代码与RTL代码分开文件

### 3. 断言模块化
```systemverilog
// 定义可复用的断言模块
module fifo_assertions #(
  parameter int DEPTH = 16
)(
  input  logic        clk,
  input  logic        rst_n,
  input  logic        wr_en,
  input  logic        rd_en,
  input  logic        full,
  input  logic        empty,
  input  logic [$clog2(DEPTH)-1:0] wr_ptr,
  input  logic [$clog2(DEPTH)-1:0] rd_ptr
);

  // 断言实现...

endmodule
```

### 4. 禁用断言
```systemverilog
// 条件禁用
`ifdef FORMAL_VERIFICATION
  assert property (...);
`endif

// 使用disable iff
assert property (@(posedge clk) disable iff (!rst_n) ...)
```

## 断言Checklist

- [ ] 所有接口协议有断言
- [ ] 关键状态转换有断言
- [ ] 边界条件有覆盖
- [ ] 断言有清晰的错误消息
- [ ] 复位期间断言正确处理
- [ ] 断言覆盖率可达100%
