# RTL 编码规范

## 命名规范

### 信号命名
| 类型 | 前缀 | 示例 |
|------|------|------|
| 时钟 | clk_ | clk_core, clk_bus |
| 复位 | rst_n_ / rst_ | rst_n_sys, rst_async |
| 使能 | en_ / _en | en_write, fifo_en |
| 选择 | sel_ / _sel | sel_mode, mux_sel |
| 计数器 | cnt_ / _cnt | cnt_state, burst_cnt |
| 状态 | state_ / _state | state_curr, next_state |
| 指针 | ptr_ / _ptr | ptr_rd, wr_ptr |
| 标志 | flag_ / _flag | flag_valid, busy_flag |
| 参数 | P_ | P_DATA_WIDTH, P_DEPTH |

### 模块命名
- 使用小写下划线命名法
- 模块名应体现功能：`dma_controller`, `axi_adapter`
- 顶层模块加 `_top` 后缀

### 文件命名
- 文件名与模块名一致
- 一个文件一个模块
- 使用 `.sv` 扩展名

## 格式规范

### 缩进
- 使用4空格缩进，不使用Tab
- case语句内部缩进

### 对齐
- 端口声明对齐
- 参数声明对齐
- 赋值语句对齐

```systemverilog
// 好的例子
module example #(
  parameter int P_DATA_WIDTH = 32,
  parameter int P_ADDR_WIDTH = 16
)(
  input  logic                  clk,
  input  logic                  rst_n,
  input  logic [P_DATA_WIDTH-1:0] data_in,
  output logic [P_DATA_WIDTH-1:0] data_out
);
```

## 可综合性规则

### 禁止使用的结构
```systemverilog
// 禁止：initial块
initial begin ... end  // 不可综合

// 禁止：延时
#10 clk = ~clk;  // 不可综合

// 禁止：while循环（综合工具支持有限）
while (cnt > 0) ...  // 避免

// 禁止：递归调用
function void foo();
  foo();  // 不可综合
endfunction
```

### 推荐的写法

```systemverilog
// 推荐：使用always_ff表示时序逻辑
always_ff @(posedge clk or negedge rst_n) begin
  if (!rst_n) reg_a <= '0;
  else        reg_a <= next_a;
end

// 推荐：使用always_comb表示组合逻辑
always_comb begin
  case (sel)
    2'b00: mux_out = in0;
    2'b01: mux_out = in1;
    2'b10: mux_out = in2;
    2'b11: mux_out = in3;
  endcase
end

// 推荐：使用assign进行简单组合逻辑
assign out = (sel) ? a : b;

// 推荐：使用unique case（综合工具优化）
unique case (state)
  ...
endcase
```

## 复位策略

### 同步复位 vs 异步复位
```systemverilog
// 同步复位
always_ff @(posedge clk) begin
  if (rst) reg_a <= '0;
  else     reg_a <= next_a;
end

// 异步复位，同步释放
always_ff @(posedge clk or negedge rst_n) begin
  if (!rst_n) reg_a <= '0;
  else        reg_a <= next_a;
end
```

### 复位同步器
```systemverilog
// 异步复位，同步释放
logic [1:0] rst_sync;
always_ff @(posedge clk or negedge rst_n_async) begin
  if (!rst_n_async) rst_sync <= 2'b00;
  else              rst_sync <= {rst_sync[0], 1'b1};
end
assign rst_n_sync = rst_sync[1];
```

## 注释规范

### 文件头注释
```systemverilog
//-----------------------------------------------------------------------------
// Module: module_name
// Description: 简要描述模块功能
// Author: 作者
// Date: YYYY-MM-DD
// Version: 1.0
// Modification History:
//   Date       | Author | Description
//   -----------|--------|----------------------------------------
//   YYYY-MM-DD | Author | Initial version
//-----------------------------------------------------------------------------
```

### 行内注释
- 注释说明"为什么"而非"是什么"
- 复杂逻辑前添加注释块

```systemverilog
// 好的注释
// 根据协议规范，需要等待3个周期后再采样
cnt <= cnt + 1;
if (cnt == 3) begin
  data_valid <= 1'b1;
end

// 不好的注释
cnt <= cnt + 1;  // cnt加1
```

## 参数化设计

### 使用parameter和localparam
```systemverilog
module fifo #(
  parameter int P_DATA_WIDTH = 8,
  parameter int P_DEPTH      = 16,
  localparam int P_PTR_WIDTH = $clog2(P_DEPTH)
)(
  input  logic                  clk,
  input  logic                  rst_n,
  input  logic [P_DATA_WIDTH-1:0] wr_data,
  output logic [P_DATA_WIDTH-1:0] rd_data
);
```

### 使用typedef定义类型
```systemverilog
typedef logic [P_DATA_WIDTH-1:0] data_t;
typedef enum logic [2:0] {
  IDLE, ACTIVE, DONE
} state_t;
```

## Lint规则

### 常见Lint错误
1. **未连接端口** - 检查所有端口是否正确连接
2. **位宽不匹配** - 检查赋值左右位宽一致
3. **锁存器推断** - 组合逻辑必须完整赋值
4. **多驱动** - 同一信号不能在多个always块赋值
5. **未使用信号** - 检查是否有遗漏的连接

### 避免锁存器
```systemverilog
// 危险：可能推断锁存器
always_comb begin
  if (en)
    out = in;
  // 缺少else分支
end

// 安全：完整赋值
always_comb begin
  out = '0;  // 默认值
  if (en)
    out = in;
end
```
