# 面积优化技巧

## 面积评估基础

### 常见面积单位
- NAND2门当量（Gate Equivalent）
- 单元面积（um²）
- 查找表数量（FPGA）

### 面积组成
| 类型 | 说明 |
|------|------|
| 组合逻辑 | 算术、逻辑、多路选择 |
| 时序逻辑 | 寄存器、FIFO |
| 存储器 | SRAM、ROM |
| 空白空间 | 布局布线开销 |

## RTL级面积优化

### 1. 资源共享
```systemverilog
// 禁止：多个运算单元
assign sum = a + b;
assign diff = c - d;
assign prod = e * f;

// 推荐：时分复用
always_ff @(posedge clk) begin
  case (op)
    ADD:  result <= a + b;
    SUB:  result <= c - d;
    MUL:  result <= e * f;
  endcase
end
```

### 2. 减少寄存器数量
```systemverilog
// 禁止：每个状态独立寄存器
always_ff @(posedge clk) begin
  case (state)
    IDLE:   idle_reg <= data;
    ACTIVE: active_reg <= data;
    DONE:   done_reg <= data;
  endcase
end

// 推荐：共享寄存器
always_ff @(posedge clk) begin
  data_reg <= data;  // 一个寄存器
end
```

### 3. 优化位宽
```systemverilog
// 禁止：过大位宽
logic [31:0] counter;  // 如果只需要计数到1000

// 推荐：合适的位宽
logic [9:0] counter;  // 1024足够
```

### 4. 状态编码优化
```systemverilog
// 独热码：状态多时面积大，速度快
typedef enum logic [7:0] {
  STATE_A = 8'b00000001,
  STATE_B = 8'b00000010,
  // ...
} state_t;

// 二进制编码：面积小，速度慢
typedef enum logic [2:0] {
  STATE_A = 3'b000,
  STATE_B = 3'b001,
  // ...
} state_t;

// 格雷码：低功耗，面积适中
```

### 5. 使用存储器替代寄存器
```systemverilog
// 禁止：大数组使用寄存器
logic [31:0] registers [0:255];  // 256个32位寄存器

// 推荐：使用SRAM
// 在综合时例化SRAM宏单元
```

## 架构级面积优化

### 1. 时分复用
- 同一硬件在不同时间处理不同数据
- 用时间换空间

### 2. 模块复用
- 设计可配置的通用模块
- 避免重复设计类似功能

### 3. 层次化存储
- 大容量慢速存储 + 小容量快速缓存
- 减少片上存储器总量

## 综合级面积优化

### 设置面积优化
```tcl
# 面积优先综合
set_max_area 0
compile -area_effort high

# 平衡面积和时序
compile_ultra -area_high_effort

# 报告面积
report_area
report_area -hierarchy
```

### 优化选项
```tcl
# 资源共享
set_resource_sharing on

# 自动状态机编码
set_fsm_encoding_style auto

# 优化层次边界
set_optimize_merge_sequential_design on
```

## 面积优化Checklist

- [ ] 位宽分析：是否使用过大位宽
- [ ] 资源共享：是否可复用运算单元
- [ ] 存储器选择：寄存器 vs SRAM
- [ ] 状态编码：独热码 vs 二进制
- [ ] 死代码消除：是否有未使用逻辑
- [ ] 层次优化：是否可合并小模块
