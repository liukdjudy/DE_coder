# 时序违例修复策略

## 时序分析基础

### 关键概念
- **Setup Time（建立时间）**：数据在时钟沿之前必须稳定的时间
- **Hold Time（保持时间）**：数据在时钟沿之后必须稳定的时间
- **Clock Skew（时钟偏斜）**：时钟到达不同寄存器的时间差
- **Critical Path（关键路径）**：延迟最长的路径

### 时序违例类型
| 类型 | 原因 | 修复策略 |
|------|------|----------|
| Setup违例 | 路径延迟过长 | 打拍、优化逻辑 |
| Hold违例 | 路径延迟过短 | 增加延迟、调整时钟树 |

## Setup违例修复

### 1. 插入流水线寄存器
```systemverilog
// 修复前：组合逻辑过长
assign out = a * b + c * d - e * f;

// 修复后：插入流水级
always_ff @(posedge clk) begin
  stage1 <= a * b;
  stage2 <= c * d;
end

always_ff @(posedge clk) begin
  stage3 <= stage1 + stage2;
end

always_ff @(posedge clk) begin
  out <= stage3 - e * f;  // 或继续打拍
end
```

### 2. 逻辑优化
- 提取公共子表达式
- 使用查找表（LUT）替代复杂计算
- 展开循环减少控制逻辑

### 3. 调整约束
- 检查时钟约束是否合理
- 确认多周期路径约束
- 添加假路径约束

```tcl
# 多周期路径约束
set_multicycle_path 2 -setup -from [get_cells reg_a] -to [get_cells reg_b]
set_multicycle_path 1 -hold -from [get_cells reg_a] -to [get_cells reg_b]

# 假路径约束
set_false_path -from [get_cells async_reg*]
```

### 4. 使用更快的标准单元
- 替换高VT为低VT单元
- 使用更大驱动强度的单元

## Hold违例修复

### 1. 插入缓冲器
- 在数据路径插入buffer
- 工具自动插入，无需手动

### 2. 调整时钟树
- 减少时钟偏斜
- 优化CTS策略

## 综合优化策略

### 1. RTL级优化
```systemverilog
// 低效写法
if (condition_a && condition_b && condition_c && condition_d)
  out = in;

// 优化：拆分条件
wire cond_stage1 = condition_a && condition_b;
wire cond_stage2 = condition_c && condition_d;
assign out_en = cond_stage1 && cond_stage2;
```

### 2. 综合约束
```tcl
# 设置设计约束
set_max_fanout 20 [current_design]

# 设置关键路径权重
set_cost_priority -max_delay

# 面积约束
set_max_area 0
```

### 3. 综合选项
```tcl
# 高性能综合
compile_ultra -timing_high_effort

# 面积优化
compile -map_effort high -area_effort high
```

## 常见问题诊断

### 1. 查看时序报告
```tcl
report_timing -from [get_cells start_reg] -to [get_cells end_reg]
report_timing -slack_lesser_than 0
```

### 2. 识别关键路径
```tcl
report_timing -max_paths 10 -slack_lesser_than 0
```

### 3. 检查约束
```tcl
report_clock
report_clock_latency
report_input_delay
report_output_delay
```

## 设计优化Checklist

- [ ] 检查时钟约束是否完整
- [ ] 检查IO约束是否正确
- [ ] 检查多周期路径约束
- [ ] 检查假路径约束
- [ ] 分析关键路径组成
- [ ] 评估流水线插入位置
- [ ] 检查组合逻辑深度
- [ ] 检查高扇出网络
