# 常用架构模式

## 1. 流水线设计

### 基本流水线结构
```
Stage 1    Stage 2    Stage 3    Stage 4
[IF] -> [ID] -> [EX] -> [WB]
 |        |         |        |
reg      reg       reg      reg
```

### 流水线设计要点
- 每级流水打拍位置选择：在逻辑较长的路径中间插入
- 前递（Forwarding）：解决数据冒险
- 旁路（Bypass）：跳过某些处理阶段
- 流水线暂停：处理控制冒险

### 流水线寄存器模板
```systemverilog
always_ff @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin
    stage_reg <= '0;
  end else if (stall) begin
    stage_reg <= stage_reg;  // 保持
  end else begin
    stage_reg <= stage_next; // 更新
  end
end
```

## 2. 状态机设计

### Moore vs Mealy
- **Moore状态机**：输出仅依赖当前状态
  - 优点：输出稳定，无毛刺
  - 缺点：状态数可能更多
- **Mealy状态机**：输出依赖当前状态和输入
  - 优点：状态数更少，响应更快
  - 缺点：输出可能有毛刺

### 三段式状态机模板
```systemverilog
// 状态定义
typedef enum logic [2:0] {
  IDLE   = 3'b001,
  ACTIVE = 3'b010,
  DONE   = 3'b100
} state_t;

// 状态寄存器
state_t state, next_state;

// 状态转移（时序逻辑）
always_ff @(posedge clk or negedge rst_n) begin
  if (!rst_n) state <= IDLE;
  else        state <= next_state;
end

// 下一状态逻辑（组合逻辑）
always_comb begin
  next_state = state;  // 默认保持
  case (state)
    IDLE:   if (start) next_state = ACTIVE;
    ACTIVE: if (done)  next_state = DONE;
    DONE:               next_state = IDLE;
    default: next_state = IDLE;
  endcase
end

// 输出逻辑
always_comb begin
  output_sig = (state == ACTIVE);
end
```

## 3. FIFO设计

### 同步FIFO
- 读写同一时钟域
- 使用计数器或指针判断满空

### 异步FIFO
- 读写不同时钟域
- 格雷码指针 + 同步器
- 深度设计：2^n

### FIFO深度计算
- 写入带宽 W，读取带宽 R
- 突发长度 B
- 深度 D ≥ B × (W - R) / W

### 异步FIFO模板
```systemverilog
// 格雷码转换
function automatic [PTR_WIDTH:0] binary2gray(input [PTR_WIDTH:0] bin);
  binary2gray = bin ^ (bin >> 1);
endfunction

// 满判断（在写时钟域）
wire full = (wr_ptr_gray == {~rd_ptr_gray_sync[PTR_WIDTH:PTR_WIDTH-1],
                              rd_ptr_gray_sync[PTR_WIDTH-2:0]});

// 空判断（在读时钟域）
wire empty = (rd_ptr_gray == wr_ptr_gray_sync);
```

## 4. 仲裁器设计

### 固定优先级仲裁器
```systemverilog
// 简单优先级编码
always_comb begin
  grant = '0;
  for (int i = 0; i < N; i++) begin
    if (request[i]) begin
      grant[i] = 1'b1;
      break;
    end
  end
end
```

### 轮询仲裁器
```systemverilog
// 使用掩码实现轮询
reg [N-1:0] mask;
always_ff @(posedge clk) begin
  if (grant != '0)
    mask <= {grant[N-2:0], grant[N-1]};  // 旋转掩码
end
```

### 加权公平仲裁器
- 每个请求者分配权重
- 使用计数器跟踪已授权次数
- 长期公平性保证

## 5. 时钟域交叉（CDC）

### 单比特信号
- 使用双触发器同步器
- 注意：不适用于快时钟域到慢时钟域

```systemverilog
always_ff @(posedge dst_clk or negedge dst_rst_n) begin
  if (!dst_rst_n) begin
    sync_reg <= 2'b00;
  end else begin
    sync_reg <= {sync_reg[0], src_signal};
  end
end
assign dst_signal = sync_reg[1];
```

### 多比特信号
- 使用握手协议
- 或使用FIFO

### 握手协议模板
```systemverilog
// 发送端
always_ff @(posedge src_clk) begin
  if (src_valid && src_ready) begin
    data_reg <= src_data;
  end
end

// 接收端（使用同步器）
```

## 6. 总线接口

### AXI4-Lite 接口要点
- 5个独立通道：AW, W, B, AR, R
- 握手协议：VALID/READY
- 字节选通：WSTRB

### AXI4-Stream 接口要点
- TVALID, TREADY 握手
- TLAST 标识包尾
- TKEEP, TSTRB 数据有效

### APB 接口要点
- 简单的两周期传输
- PSEL, PENABLE, PWRITE
- 适合低带宽外设
