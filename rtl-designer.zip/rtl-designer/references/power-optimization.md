# 功耗优化技巧

## 功耗基础

### 功耗组成
| 类型 | 公式 | 占比 |
|------|------|------|
| 动态功耗 | P_dyn = α × C × V² × f | 70-90% |
| 静态功耗 | P_static = I_leak × V | 10-30% |

### 动态功耗因素
- **α**：翻转率（Switching Activity）
- **C**：负载电容
- **V**：电压
- **f**：频率

## RTL级功耗优化

### 1. 门控时钟（Clock Gating）
```systemverilog
// 禁止：用使能信号多路选择
always_ff @(posedge clk) begin
  if (en)
    reg_out <= data_in;
end

// 推荐：使用门控时钟
logic clk_gated;
always_comb begin
  clk_gated = clk & en;  // 实际中用专门的时钟门控单元
end

always_ff @(posedge clk_gated) begin
  reg_out <= data_in;
end

// 工具自动推断门控时钟
always_ff @(posedge clk) begin
  if (en)
    reg_out <= data_in;
end
// 设置综合选项使能门控时钟推断
```

### 2. 操作数隔离（Operand Isolation）
```systemverilog
// 禁止：持续计算
assign result = a * b;  // 即使result不使用也在计算

// 推荐：条件使能
assign result_en = (state == COMPUTE) ? a * b : '0;
```

### 3. 减少翻转率
```systemverilog
// 禁止：高位频繁翻转
logic [31:0] counter;
always_ff @(posedge clk) counter <= counter + 1;

// 推荐：分离计数
logic [7:0] counter_low;
logic [7:0] counter_high;
always_ff @(posedge clk) begin
  counter_low <= counter_low + 1;
  if (counter_low == '1)
    counter_high <= counter_high + 1;
end
```

### 4. 状态编码优化
```systemverilog
// 高翻转编码
typedef enum logic [2:0] {
  STATE_A = 3'b000,
  STATE_B = 3'b111,  // 多位翻转
  STATE_C = 3'b000   // 与A相同，不好
} state_t;

// 低翻转编码（格雷码）
typedef enum logic [2:0] {
  STATE_A = 3'b000,
  STATE_B = 3'b001,  // 单位翻转
  STATE_C = 3'b011,
  STATE_D = 3'b010
} state_t;
```

### 5. 数据通路优化
```systemverilog
// 禁止：不必要的数据翻转
assign data_out = (sel) ? data_a : data_b;  // sel变化时总在翻转

// 推荐：保持数据稳定
assign data_out_valid = (sel) ? data_a_valid : data_b_valid;
assign data_out = (sel) ? data_a : data_out;  // 保持上一次值
```

## 架构级功耗优化

### 1. 电源域划分
- 将不同功能模块划分到不同电源域
- 空闲模块可断电

### 2. 频率与电压调整
- 根据性能需求动态调整DVFS
- 低负载时降低电压频率

### 3. 休眠模式
- 空闲时进入低功耗模式
- 关闭不必要模块的时钟

## 综合级功耗优化

### 设置功耗优化
```tcl
# 使能门控时钟
set_clock_gating_style -sequential_cell latch

# 功耗优先综合
compile_ultra -gate_clock -power

# 设置功耗约束
set_max_dynamic_power 100mW
set_max_leakage_power 10mW
```

### 功耗分析
```tcl
# 读入翻转率文件
read_saif -input design.saif

# 报告功耗
report_power
report_power -hierarchy
```

## 功耗优化Checklist

- [ ] 门控时钟覆盖率 > 90%
- [ ] 空闲模块时钟可关闭
- [ ] 减少不必要的组合逻辑翻转
- [ ] 状态机使用低功耗编码
- [ ] 高频路径使用低VT单元
- [ ] 非关键路径使用高VT单元
- [ ] 电源域划分合理
