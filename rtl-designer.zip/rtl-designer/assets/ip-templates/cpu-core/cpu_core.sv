//-----------------------------------------------------------------------------
// Module: cpu_core
// Description: 简单CPU核模板 - 取指、译码、执行、写回四级流水
// Author: 
// Date:
//-----------------------------------------------------------------------------

module cpu_core #(
  parameter int P_DATA_WIDTH = 32,
  parameter int P_ADDR_WIDTH = 32,
  parameter int P_REG_NUM    = 32
)(
  input  logic                     clk,
  input  logic                     rst_n,

  // 指令接口
  output logic [P_ADDR_WIDTH-1:0]  imem_addr,
  input  logic [P_DATA_WIDTH-1:0]  imem_data,
  output logic                     imem_valid,
  input  logic                     imem_ready,

  // 数据接口
  output logic [P_ADDR_WIDTH-1:0]  dmem_addr,
  output logic [P_DATA_WIDTH-1:0]  dmem_wdata,
  input  logic [P_DATA_WIDTH-1:0]  dmem_rdata,
  output logic                     dmem_valid,
  output logic                     dmem_write,
  input  logic                     dmem_ready
);

  //==========================================================================
  // 参数定义
  //==========================================================================
  localparam int REG_ADDR_WIDTH = $clog2(P_REG_NUM);

  //==========================================================================
  // 状态定义
  //==========================================================================
  typedef enum logic [1:0] {
    IDLE   = 2'b00,
    ACTIVE = 2'b01,
    HALT   = 2'b10
  } state_t;

  //==========================================================================
  // 信号定义
  //==========================================================================
  // 流水线寄存器
  state_t state;

  // IF阶段
  logic [P_ADDR_WIDTH-1:0] pc;
  logic [P_DATA_WIDTH-1:0] if_instr;

  // ID阶段
  logic [P_DATA_WIDTH-1:0] id_instr;
  logic [REG_ADDR_WIDTH-1:0] id_rs1, id_rs2, id_rd;

  // EX阶段
  logic [P_DATA_WIDTH-1:0] ex_alu_result;

  // WB阶段
  logic [P_DATA_WIDTH-1:0] wb_result;

  // 寄存器堆
  logic [P_DATA_WIDTH-1:0] reg_file [0:P_REG_NUM-1];

  //==========================================================================
  // 流水线逻辑
  //==========================================================================

  // IF: 取指
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pc <= '0;
    end else if (imem_ready) begin
      pc <= pc + 4;
    end
  end

  assign imem_addr  = pc;
  assign imem_valid = (state == ACTIVE);

  // ID: 译码
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      id_instr <= '0;
    end else begin
      id_instr <= if_instr;
    end
  end

  assign id_rs1 = id_instr[19:15];
  assign id_rs2 = id_instr[24:20];
  assign id_rd  = id_instr[11:7];

  // EX: 执行
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ex_alu_result <= '0;
    end else begin
      // ALU操作
      ex_alu_result <= reg_file[id_rs1] + reg_file[id_rs2];
    end
  end

  // WB: 写回
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wb_result <= '0;
    end else begin
      wb_result <= ex_alu_result;
      if (id_rd != 0) begin
        reg_file[id_rd] <= ex_alu_result;
      end
    end
  end

  //==========================================================================
  // 状态机
  //==========================================================================
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= IDLE;
    end else begin
      case (state)
        IDLE:   state <= ACTIVE;
        ACTIVE: state <= ACTIVE;
        HALT:   state <= HALT;
        default: state <= IDLE;
      endcase
    end
  end

endmodule
