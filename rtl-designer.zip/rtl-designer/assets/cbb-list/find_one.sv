//-----------------------------------------------------------------------------
// Module: find_first_one
// Description: 找到输入中第一个为1的位（最低位优先）
// Parameters:
//   WIDTH - 输入位宽
// Ports:
//   in[WIDTH]    - 输入向量
//   out[log2]    - 第一个1的位置
//   valid        - 是否找到1
//-----------------------------------------------------------------------------

module find_first_one #(
  parameter int WIDTH = 32
)(
  input  logic [WIDTH-1:0]         in,
  output logic [$clog2(WIDTH)-1:0] out,
  output logic                     valid
);

  localparam int IDX_WIDTH = $clog2(WIDTH);

  // 二叉树查找
  always_comb begin
    out = '0;
    valid = |in;

    for (int i = IDX_WIDTH - 1; i >= 0; i--) begin
      // 检查高位是否有1
      if (in >> (1 << i)) begin
        out[i] = 1'b1;
      end
    end
  end

  // 更清晰的实现
  generate
    if (WIDTH == 1) begin : gen_w1
      assign out = 1'b0;
      assign valid = in[0];
    end else if (WIDTH == 2) begin : gen_w2
      assign out = ~in[0];
      assign valid = |in;
    end else begin : gen_wider
      // 使用内置函数
      always_comb begin
        out = '0;
        for (int i = 0; i < WIDTH; i++) begin
          if (in[i] && out == '0) begin
            out = IDX_WIDTH'(i);
          end
        end
      end
      assign valid = |in;
    end
  endgenerate

endmodule
