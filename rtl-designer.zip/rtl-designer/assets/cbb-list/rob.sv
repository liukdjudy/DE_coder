//-----------------------------------------------------------------------------
// Module: rob (Reorder Buffer)
// Description: 重排序缓冲，用于乱序执行结果重排序
// Parameters:
//   WIDTH   - 数据位宽
//   DEPTH   - 深度（必须是2的幂次）
//   TAG_WIDTH - 标签位宽
// Ports:
//   clk, rst_n      - 时钟复位
//   alloc_en        - 分配请求
//   alloc_tag       - 分配的标签
//   alloc_full      - 无法分配
//   commit_en       - 提交请求
//   commit_tag      - 提交标签
//   commit_data     - 提交数据
//   retire_valid    - 可退休
//   retire_data     - 退休数据
//   flush           - 冲刷
//-----------------------------------------------------------------------------

module rob #(
  parameter int WIDTH     = 32,
  parameter int DEPTH     = 16,
  parameter int TAG_WIDTH = $clog2(DEPTH)
)(
  input  logic                   clk,
  input  logic                   rst_n,
  // 分配接口
  input  logic                   alloc_en,
  output logic [TAG_WIDTH-1:0]   alloc_tag,
  output logic                   alloc_full,
  // 写回接口
  input  logic                   wb_en,
  input  logic [TAG_WIDTH-1:0]   wb_tag,
  input  logic [WIDTH-1:0]       wb_data,
  // 退休接口
  output logic                   retire_valid,
  output logic [WIDTH-1:0]       retire_data,
  // 冲刷
  input  logic                   flush
);

  localparam int PTR_WIDTH = $clog2(DEPTH);

  // ROB条目
  typedef struct packed {
    logic               valid;
    logic               ready;
    logic [WIDTH-1:0]   data;
  } rob_entry_t;

  rob_entry_t entries [0:DEPTH-1];

  // 头尾指针
  logic [PTR_WIDTH-1:0] head_ptr;
  logic [PTR_WIDTH-1:0] tail_ptr;
  logic [PTR_WIDTH:0]   count;

  // 满空判断
  assign alloc_full = (count == DEPTH);
  assign retire_valid = entries[head_ptr].valid && entries[head_ptr].ready;

  // 分配逻辑
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tail_ptr <= '0;
      count <= '0;
    end else if (flush) begin
      tail_ptr <= '0;
      count <= '0;
    end else if (alloc_en && !alloc_full) begin
      tail_ptr <= tail_ptr + 1'b1;
      count <= count + 1'b1;
    end else if (retire_valid) begin
      if (alloc_en && !alloc_full)
        count <= count;
      else
        count <= count - 1'b1;
    end
  end

  assign alloc_tag = tail_ptr;

  // 条目写入
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < DEPTH; i++) begin
        entries[i].valid <= '0;
        entries[i].ready <= '0;
        entries[i].data <= '0;
      end
    end else if (flush) begin
      for (int i = 0; i < DEPTH; i++) begin
        entries[i].valid <= '0;
        entries[i].ready <= '0;
      end
    end else begin
      // 分配
      if (alloc_en && !alloc_full) begin
        entries[tail_ptr].valid <= 1'b1;
        entries[tail_ptr].ready <= 1'b0;
      end
      // 写回
      if (wb_en) begin
        entries[wb_tag].ready <= 1'b1;
        entries[wb_tag].data <= wb_data;
      end
      // 退休
      if (retire_valid) begin
        entries[head_ptr].valid <= 1'b0;
        entries[head_ptr].ready <= 1'b0;
      end
    end
  end

  // 头指针更新
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      head_ptr <= '0;
    end else if (flush) begin
      head_ptr <= '0;
    end else if (retire_valid) begin
      head_ptr <= head_ptr + 1'b1;
    end
  end

  // 退休数据
  assign retire_data = entries[head_ptr].data;

endmodule
