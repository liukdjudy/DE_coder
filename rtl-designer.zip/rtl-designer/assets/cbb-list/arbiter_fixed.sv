//-----------------------------------------------------------------------------
// Module: arbiter_fixed
// Description: 固定优先级仲裁器
// Parameters:
//   N - 请求者数量
// Ports:
//   req[N]   - 请求信号，高有效
//   grant[N] - 授权信号，独热码
// Note: 优先级从低位到高位递减，req[0]优先级最高
//-----------------------------------------------------------------------------

module arbiter_fixed #(
  parameter int N = 4
)(
  input  logic [N-1:0] req,
  output logic [N-1:0] grant
);

  // 使用优先编码器
  logic [$clog2(N)-1:0] grant_idx;
  logic valid;

  find_first_one #(.WIDTH(N)) u_encoder (
    .in(req),
    .out(grant_idx),
    .valid(valid)
  );

  // 独热码输出
  always_comb begin
    grant = '0;
    if (valid)
      grant[grant_idx] = 1'b1;
  end

  // 断言
  `ifdef FORMAL
    // 有请求时必须有授权
    assert property (@(req) |req| -> |grant|);
    // 授权必须是独热码或全零
    assert property (@(grant) $onehot0(grant));
    // 无请求时无授权
    assert property (@(req, grant) req == '0 -> grant == '0);
  `endif

endmodule
