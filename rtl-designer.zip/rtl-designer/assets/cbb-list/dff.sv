//-----------------------------------------------------------------------------
// Module: dff (D Flip-Flop)
// Description: 通用翻转触发器，支持复位、使能
// Parameters:
//   WIDTH - 数据位宽
//   RESET_VALUE - 复位值
// Usage:
//   dff #(32, '0) u_reg (.clk, .rst_n, .d(next), .q(curr));
//-----------------------------------------------------------------------------

module dff #(
  parameter int WIDTH       = 1,
  parameter bit [WIDTH-1:0] RESET_VALUE = '0
)(
  input  logic               clk,
  input  logic               rst_n,
  input  logic               en,        // 使能信号，可选
  input  logic [WIDTH-1:0]   d,
  output logic [WIDTH-1:0]   q
);

  // 不使用使能时的默认行为
  logic en_internal;
  assign en_internal = (en === 1'bz) ? 1'b1 : en;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q <= RESET_VALUE;
    end else if (en_internal) begin
      q <= d;
    end
  end

  // 断言
  `ifdef FORMAL
    // 复位后输出应为复位值
    assert property (@(posedge clk) !rst_n |=> q == RESET_VALUE);
    // 使能有效时下一周期输出应为输入
    assert property (@(posedge clk) rst_n && en_internal |=> q == $past(d));
  `endif

endmodule
