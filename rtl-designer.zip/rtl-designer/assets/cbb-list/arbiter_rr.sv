//-----------------------------------------------------------------------------
// Module: arbiter_rr
// Description: 轮询仲裁器（Round Robin）
// Parameters:
//   N - 请求者数量
// Ports:
//   clk, rst_n - 时钟复位
//   req[N]     - 请求信号
//   grant[N]   - 授权信号，独热码
// Algorithm: 从上次授权的下一位置开始轮询
//-----------------------------------------------------------------------------

module arbiter_rr #(
  parameter int N = 4
)(
  input  logic         clk,
  input  logic         rst_n,
  input  logic [N-1:0] req,
  output logic [N-1:0] grant
);

  localparam int PTR_WIDTH = $clog2(N);

  // 轮询指针
  logic [PTR_WIDTH-1:0] rr_ptr;

  // 轮询指针更新
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rr_ptr <= '0;
    end else if (|grant) begin
      // 移动到下一个位置
      rr_ptr <= rr_ptr + 1'b1;
    end
  end

  // 带掩码的优先编码
  logic [N-1:0] masked_req;
  logic [N-1:0] high_grant;
  logic [N-1:0] low_grant;
  logic high_valid, low_valid;

  // 高优先级区域：从指针到最高位
  assign masked_req = req & ~((1 << rr_ptr) - 1);

  find_first_one #(.WIDTH(N)) u_high (
    .in(masked_req),
    .out(/* unused */),
    .valid(high_valid)
  );

  // 低优先级区域：从0到指针-1
  assign low_grant = req & ((1 << rr_ptr) - 1);

  find_first_one #(.WIDTH(N)) u_low (
    .in(low_grant),
    .out(/* unused */),
    .valid(low_valid)
  );

  // 优先选择高优先级区域
  always_comb begin
    if (high_valid) begin
      grant = masked_req & (masked_req & (-masked_req));  // 取最低位1
    end else if (low_valid) begin
      grant = low_grant & (low_grant & (-low_grant));
    end else begin
      grant = '0;
    end
  end

  // 简化实现：使用循环
  always_comb begin
    logic [N-1:0] temp_grant;
    temp_grant = '0;
    for (int i = 0; i < N; i++) begin
      int idx = (rr_ptr + i) % N;
      if (req[idx] && temp_grant == '0) begin
        temp_grant[idx] = 1'b1;
      end
    end
    grant = temp_grant;
  end

endmodule
