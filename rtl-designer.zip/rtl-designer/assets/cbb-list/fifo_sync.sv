//-----------------------------------------------------------------------------
// Module: fifo_sync
// Description: 同步FIFO，单时钟域
// Parameters:
//   WIDTH - 数据位宽
//   DEPTH - 深度（必须是2的幂次）
// Ports:
//   clk, rst_n - 时钟复位
//   wr_en, wr_data - 写接口
//   rd_en, rd_data - 读接口
//   full, empty    - 状态信号
//   count          - 当前数据量（可选）
//-----------------------------------------------------------------------------

module fifo_sync #(
  parameter int WIDTH = 32,
  parameter int DEPTH = 16,
  parameter bit  COUNT_ENABLE = 1'b1
)(
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic                 wr_en,
  input  logic [WIDTH-1:0]     wr_data,
  input  logic                 rd_en,
  output logic [WIDTH-1:0]     rd_data,
  output logic                 full,
  output logic                 empty,
  output logic [$clog2(DEPTH):0] count
);

  localparam int PTR_WIDTH = $clog2(DEPTH);

  // 存储器
  logic [WIDTH-1:0] mem [0:DEPTH-1];

  // 读写指针
  logic [PTR_WIDTH:0] wr_ptr;
  logic [PTR_WIDTH:0] rd_ptr;

  // 满空判断（使用格雷码高位区分）
  assign full  = (wr_ptr[PTR_WIDTH] != rd_ptr[PTR_WIDTH]) &&
                 (wr_ptr[PTR_WIDTH-1:0] == rd_ptr[PTR_WIDTH-1:0]);
  assign empty = (wr_ptr == rd_ptr);

  // 写操作
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wr_ptr <= '0;
    end else if (wr_en && !full) begin
      mem[wr_ptr[PTR_WIDTH-1:0]] <= wr_data;
      wr_ptr <= wr_ptr + 1'b1;
    end
  end

  // 读操作
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_ptr <= '0;
    end else if (rd_en && !empty) begin
      rd_ptr <= rd_ptr + 1'b1;
    end
  end

  // 读数据
  assign rd_data = mem[rd_ptr[PTR_WIDTH-1:0]];

  // 计数器
  generate
    if (COUNT_ENABLE) begin : gen_count
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          count <= '0;
        end else begin
          case ({wr_en && !full, rd_en && !empty})
            2'b10:  count <= count + 1'b1;
            2'b01:  count <= count - 1'b1;
            default: count <= count;
          endcase
        end
      end
    end else begin : gen_no_count
      assign count = '0;
    end
  endgenerate

  // 断言
  `ifdef FORMAL
    // 满时不写
    assert property (@(posedge clk) full |-> !wr_en);
    // 空时不读
    assert property (@(posedge clk) empty |-> !rd_en);
    // 计数不超过深度
    assert property (@(posedge clk) count <= DEPTH);
  `endif

endmodule
