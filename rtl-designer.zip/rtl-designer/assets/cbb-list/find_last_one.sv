//-----------------------------------------------------------------------------
// Module: find_last_one
// Description: 找到输入中最后一个为1的位（最高位优先）
//-----------------------------------------------------------------------------

module find_last_one #(
  parameter int WIDTH = 32
)(
  input  logic [WIDTH-1:0]         in,
  output logic [$clog2(WIDTH)-1:0] out,
  output logic                     valid
);

  localparam int IDX_WIDTH = $clog2(WIDTH);

  always_comb begin
    out = '0;
    valid = |in;

    for (int i = WIDTH - 1; i >= 0; i--) begin
      if (in[i]) begin
        out = IDX_WIDTH'(i);
        break;
      end
    end
  end

endmodule
