# CBB 通用构建块列表

本目录包含经过验证的基础 RTL 模块，设计时应优先使用这些 CBB，避免重复造轮子。

## CBB 列表

### 基础寄存器

| 模块 | 文件 | 描述 |
|------|------|------|
| dff | `dff.sv` | D触发器，支持异步复位、使能 |
| dff_r | `dff_r.sv` | D触发器，同步复位 |

### 仲裁器

| 模块 | 文件 | 描述 |
|------|------|------|
| arbiter_fixed | `arbiter_fixed.sv` | 固定优先级仲裁器 |
| arbiter_rr | `arbiter_rr.sv` | 轮询仲裁器 |

### 编码器

| 模块 | 文件 | 描述 |
|------|------|------|
| find_first_one | `find_one.sv` | 找最低位1的位置 |
| find_last_one | `find_last_one.sv` | 找最高位1的位置 |

### FIFO

| 模块 | 文件 | 描述 |
|------|------|------|
| fifo_sync | `fifo_sync.sv` | 同步FIFO，单时钟域 |
| fifo_async | `fifo_async.sv` | 异步FIFO，跨时钟域 |

### 其他

| 模块 | 文件 | 描述 |
|------|------|------|
| rob | `rob.sv` | 重排序缓冲，乱序执行 |
| skid_buffer | `skid_buffer.sv` | Skid缓冲，背压处理 |

## 使用方法

### 1. 例化 CBB

```systemverilog
// 例化 DFF
dff #(.WIDTH(32), .RESET_VALUE('0)) u_reg (
  .clk(clk),
  .rst_n(rst_n),
  .en(1'b1),
  .d(next_state),
  .q(current_state)
);

// 例化同步 FIFO
fifo_sync #(.WIDTH(64), .DEPTH(16)) u_fifo (
  .clk(clk),
  .rst_n(rst_n),
  .wr_en(wr_en),
  .wr_data(wr_data),
  .rd_en(rd_en),
  .rd_data(rd_data),
  .full(full),
  .empty(empty)
);
```

### 2. 参数说明

所有 CBB 都支持参数化配置：

- **WIDTH**: 数据位宽
- **DEPTH**: 深度（FIFO/ROB等）
- **RESET_VALUE**: 复位值（寄存器等）

### 3. 接口规范

#### 寄存器接口
```systemverilog
input  logic clk, rst_n, en;
input  logic [WIDTH-1:0] d;
output logic [WIDTH-1:0] q;
```

#### FIFO接口
```systemverilog
// 写接口
input  logic wr_en;
input  logic [WIDTH-1:0] wr_data;
output logic full;

// 读接口
input  logic rd_en;
output logic [WIDTH-1:0] rd_data;
output logic empty;
```

#### AXI-Stream风格接口
```systemverilog
// 从设备接口（输入）
input  logic s_valid;
output logic s_ready;
input  logic [WIDTH-1:0] s_data;

// 主设备接口（输出）
output logic m_valid;
input  logic m_ready;
output logic [WIDTH-1:0] m_data;
```

## 设计规范

1. **所有 CBB 必须通过验证** - 功能覆盖率和断言覆盖率需达100%
2. **参数化设计** - 支持位宽、深度等参数配置
3. **统一命名** - clk, rst_n, en 等信号命名保持一致
4. **包含断言** - 使用 `ifdef FORMAL` 包含形式验证断言
5. **文档完整** - 模块头包含功能描述、参数说明、接口说明

## 添加新 CBB

1. 创建 `new_cbb.sv` 文件
2. 包含完整的模块头注释
3. 使用参数化设计
4. 添加形式验证断言
5. 更新本 README 文件
6. 提交验证
