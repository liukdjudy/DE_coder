//-----------------------------------------------------------------------------
// Module: skid_buffer
// Description: Skid缓冲，用于处理AXI流背压
// Parameters:
//   WIDTH - 数据位宽
// Ports:
//   clk, rst_n    - 时钟复位
//   s_valid, s_ready, s_data - 从设备接口（输入）
//   m_valid, m_ready, m_data - 主设备接口（输出）
// Note: 当下游反压时，保持最后一个有效数据
//-----------------------------------------------------------------------------

module skid_buffer #(
  parameter int WIDTH = 32
)(
  input  logic               clk,
  input  logic               rst_n,
  // 从设备接口
  input  logic               s_valid,
  output logic               s_ready,
  input  logic [WIDTH-1:0]   s_data,
  // 主设备接口
  output logic               m_valid,
  input  logic               m_ready,
  output logic [WIDTH-1:0]   m_data
);

  // Skid缓冲寄存器
  logic               skid_valid;
  logic [WIDTH-1:0]   skid_data;

  // 状态
  typedef enum logic [1:0] {
    EMPTY,      // 缓冲为空
    SKID,       // 缓冲有数据，等待下游接收
    FORWARD     // 直通模式
  } state_t;

  state_t state;

  // 状态机
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= EMPTY;
      skid_valid <= 1'b0;
      skid_data <= '0;
    end else begin
      case (state)
        EMPTY: begin
          if (s_valid && !m_ready) begin
            // 上游有数据，下游不接收，存入skid
            skid_valid <= 1'b1;
            skid_data <= s_data;
            state <= SKID;
          end
        end

        SKID: begin
          if (m_ready) begin
            // 下游接收数据
            if (s_valid) begin
              // 上游继续发数据，更新skid
              skid_data <= s_data;
            end else begin
              // 上游停止，清空skid
              skid_valid <= 1'b0;
              state <= EMPTY;
            end
          end
        end

        default: state <= EMPTY;
      endcase
    end
  end

  // 输出逻辑
  always_comb begin
    case (state)
      EMPTY: begin
        m_valid = s_valid;
        m_data = s_data;
        s_ready = m_ready;
      end
      SKID: begin
        m_valid = skid_valid;
        m_data = skid_data;
        s_ready = m_ready;  // 下游准备好时才能接收新数据
      end
      default: begin
        m_valid = 1'b0;
        m_data = '0;
        s_ready = 1'b1;
      end
    endcase
  end

  // 简化实现
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      skid_data <= '0;
    end else if (s_valid && s_ready && !m_ready) begin
      // 背压时保存数据
      skid_data <= s_data;
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      skid_valid <= 1'b0;
    end else if (m_ready && skid_valid) begin
      // 下游接收，清空skid
      skid_valid <= 1'b0;
    end else if (s_valid && !m_ready && !skid_valid) begin
      // 需要skid
      skid_valid <= 1'b1;
    end
  end

  // 输出
  assign m_valid = skid_valid || s_valid;
  assign m_data = skid_valid ? skid_data : s_data;
  assign s_ready = !skid_valid || m_ready;

  // 断言
  `ifdef FORMAL
    // 不会丢数据：上游发送且下游不接收时必须存入skid
    assert property (@(posedge clk) s_valid && !m_ready |-> s_ready);
    // m_valid有效时m_data必须稳定
    assert property (@(posedge clk) m_valid && !m_ready |-> $stable(m_data));
  `endif

endmodule
