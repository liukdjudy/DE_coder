//-----------------------------------------------------------------------------
// Module: dff_r (D Flip-Flop with synchronous reset)
// Description: 同步复位的翻转触发器
//-----------------------------------------------------------------------------

module dff_r #(
  parameter int WIDTH       = 1,
  parameter bit [WIDTH-1:0] RESET_VALUE = '0
)(
  input  logic               clk,
  input  logic               rst,       // 同步复位，高有效
  input  logic               en,
  input  logic [WIDTH-1:0]   d,
  output logic [WIDTH-1:0]   q
);

  logic en_internal;
  assign en_internal = (en === 1'bz) ? 1'b1 : en;

  always_ff @(posedge clk) begin
    if (rst) begin
      q <= RESET_VALUE;
    end else if (en_internal) begin
      q <= d;
    end
  end

endmodule
