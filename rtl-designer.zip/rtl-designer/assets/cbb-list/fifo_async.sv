//-----------------------------------------------------------------------------
// Module: fifo_async
// Description: 异步FIFO，跨时钟域
// Parameters:
//   WIDTH - 数据位宽
//   DEPTH - 深度（必须是2的幂次）
// Ports:
//   wr_clk, wr_rst_n - 写时钟域
//   rd_clk, rd_rst_n - 读时钟域
//   wr_en, wr_data   - 写接口
//   rd_en, rd_data   - 读接口
//   full, empty      - 状态信号
// Note: 使用格雷码指针实现跨时钟域同步
//-----------------------------------------------------------------------------

module fifo_async #(
  parameter int WIDTH = 32,
  parameter int DEPTH = 16
)(
  input  logic                 wr_clk,
  input  logic                 wr_rst_n,
  input  logic                 rd_clk,
  input  logic                 rd_rst_n,
  input  logic                 wr_en,
  input  logic [WIDTH-1:0]     wr_data,
  input  logic                 rd_en,
  output logic [WIDTH-1:0]     rd_data,
  output logic                 full,
  output logic                 empty
);

  localparam int PTR_WIDTH = $clog2(DEPTH);

  // 存储器
  logic [WIDTH-1:0] mem [0:DEPTH-1];

  // 格雷码指针
  logic [PTR_WIDTH:0] wr_ptr_bin, wr_ptr_gray;
  logic [PTR_WIDTH:0] rd_ptr_bin, rd_ptr_gray;

  // 同步后的对方指针
  logic [PTR_WIDTH:0] rd_ptr_gray_sync;
  logic [PTR_WIDTH:0] wr_ptr_gray_sync;

  // 二进制转格雷码
  function automatic [PTR_WIDTH:0] bin2gray(input [PTR_WIDTH:0] bin);
    bin2gray = bin ^ (bin >> 1);
  endfunction

  // 格雷码转二进制
  function automatic [PTR_WIDTH:0] gray2bin(input [PTR_WIDTH:0] gray);
    logic [PTR_WIDTH:0] bin;
    bin[PTR_WIDTH] = gray[PTR_WIDTH];
    for (int i = PTR_WIDTH - 1; i >= 0; i--) begin
      bin[i] = gray[i] ^ bin[i + 1];
    end
    return bin;
  endfunction

  // 写时钟域
  always_ff @(posedge wr_clk or negedge wr_rst_n) begin
    if (!wr_rst_n) begin
      wr_ptr_bin  <= '0;
      wr_ptr_gray <= '0;
    end else if (wr_en && !full) begin
      mem[wr_ptr_bin[PTR_WIDTH-1:0]] <= wr_data;
      wr_ptr_bin  <= wr_ptr_bin + 1'b1;
      wr_ptr_gray <= bin2gray(wr_ptr_bin + 1'b1);
    end
  end

  // 读时钟域
  always_ff @(posedge rd_clk or negedge rd_rst_n) begin
    if (!rd_rst_n) begin
      rd_ptr_bin  <= '0;
      rd_ptr_gray <= '0;
    end else if (rd_en && !empty) begin
      rd_ptr_bin  <= rd_ptr_bin + 1'b1;
      rd_ptr_gray <= bin2gray(rd_ptr_bin + 1'b1);
    end
  end

  // 读数据
  assign rd_data = mem[rd_ptr_bin[PTR_WIDTH-1:0]];

  // 读指针同步到写时钟域（两级同步器）
  always_ff @(posedge wr_clk or negedge wr_rst_n) begin
    if (!wr_rst_n) begin
      rd_ptr_gray_sync <= '0;
    end else begin
      rd_ptr_gray_sync <= rd_ptr_gray;
    end
  end

  // 写指针同步到读时钟域（两级同步器）
  always_ff @(posedge rd_clk or negedge rd_rst_n) begin
    if (!rd_rst_n) begin
      wr_ptr_gray_sync <= '0;
    end else begin
      wr_ptr_gray_sync <= wr_ptr_gray;
    end
  end

  // 满判断（写时钟域）
  assign full = (wr_ptr_gray == {~rd_ptr_gray_sync[PTR_WIDTH:PTR_WIDTH-1],
                                  rd_ptr_gray_sync[PTR_WIDTH-2:0]});

  // 空判断（读时钟域）
  assign empty = (rd_ptr_gray == wr_ptr_gray_sync);

endmodule
