# Script: run_synth.tcl
# Description: 综合脚本模板
# Usage: dc_shell -f run_synth.tcl | tee synth.log

# --------------
# 1. 设置环境
# --------------
set design_name "dma_controller"
set target_lib "stdcells.db"
set link_lib "* $target_lib"

# --------------
# 2. 读取设计
# --------------
read_verilog -format sverilog ./src/*.sv
read_sdc ./constraints/constraints.sdc

# --------------
# 3. 约束设置
# --------------
current_design $design_name

# 时钟约束
create_clock -name clk -period 10 [get_ports clk]
set_clock_uncertainty -setup 0.2 [get_clocks clk]
set_clock_uncertainty -hold 0.1 [get_clocks clk]
set_clock_latency -source -max 0.5 [get_clocks clk]

# 输入输出延迟
set_input_delay -max 1.5 -clock clk [remove_from_collection [all_inputs] clk]
set_output_delay -max 1.0 -clock clk [all_outputs]

# --------------
# 4. 综合优化
# --------------
compile_ultra -gate_clock -timing_high_effort

# --------------
# 5. 报告生成
# --------------
report_qor > ./reports/qor.rpt
report_timing -max_paths 20 > ./reports/timing.rpt
report_timing -max_paths 20 -hold > ./reports/hold_timing.rpt
report_area -hierarchy > ./reports/area.rpt
report_power > ./reports/power.rpt
report_constraints -all_violators > ./reports/constraints.rpt

# --------------
# 6. 输出结果
# --------------
write -format verilog -hierarchy -output ./netlist/${design_name}.v
write_sdc -nosplit ./netlist/${design_name}.sdc

exit
